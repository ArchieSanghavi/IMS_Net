﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;


namespace IMS_Net.Admin
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString);

        SqlDataAdapter ad=null;

        SqlCommand cmd=null;

        DataTable dataTable=null;
      
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                btnupdate.Visible = false;
                FillGrid();
                ClearData();
            }
  
        }
        private void FillGrid()
        {

            dataTable = new DataTable();
            cmd = new SqlCommand("SolutionMaster", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@Action", "Select");


            cmd.Connection = conn;


            ad = new SqlDataAdapter(cmd);

            ad.Fill(dataTable);

            GridView1.DataSource = dataTable;

            GridView1.DataBind();
        }

        private void ClearData()
        {
            txtsolutioncode.Text = "";
            txtdescription.Text = "";
            rblactive.ClearSelection();
            txtcreatedby.Text = "";
            txtcreateddate.Text = "";
            txtupdatedby.Text = "";
            txtupdateddate.Text = "";
        

        }

        
        protected void btnsave_Click(object sender, EventArgs e)
        {
            try
            {
                if (Page.IsValid)
                {
                   
                    SqlCommand cmd = new SqlCommand("SolutionMaster", conn);

                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@Action", "Insert");

                    cmd.Parameters.AddWithValue("@solution_code", txtsolutioncode.Text);
                    cmd.Parameters.AddWithValue("@Description", txtdescription.Text);
                    cmd.Parameters.AddWithValue("@Active", rblactive.SelectedValue);
                    cmd.Parameters.AddWithValue("@CreatedBy", txtcreatedby.Text);
                    cmd.Parameters.AddWithValue("@CreatedDate", txtcreateddate.Text);
                    cmd.Parameters.AddWithValue("@UpdatedBy", txtupdatedby.Text);
                    cmd.Parameters.AddWithValue("@UpdatedDate", txtupdateddate.Text);

                    conn.Open();

                    cmd.Connection = conn;

                    cmd.ExecuteNonQuery();

                   ClearData();
                
                    conn.Close();

                     FillGrid();

                 
                }
            }
            catch (Exception ex) { }

        }

        protected void btnupdate_Click(object sender, EventArgs e)
        {
            try
            {
                if (Page.IsValid)
                {
                    SqlCommand cmd = new SqlCommand("SolutionMaster", conn);

                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@Action", "Update");

                    cmd.Parameters.AddWithValue("@solution_code", txtsolutioncode.Text);
                    cmd.Parameters.AddWithValue("@Description", txtdescription.Text);
                    cmd.Parameters.AddWithValue("@Active", rblactive.SelectedValue);
                    cmd.Parameters.AddWithValue("@CreatedBy", txtcreatedby.Text);
                    cmd.Parameters.AddWithValue("@CreatedDate", txtcreateddate.Text);
                    cmd.Parameters.AddWithValue("@UpdatedBy", txtupdatedby.Text);
                    cmd.Parameters.AddWithValue("@UpdatedDate", txtupdateddate.Text);

                    if (conn.State == ConnectionState.Closed)
                    {
                        conn.Open();
                    }
                    cmd.ExecuteNonQuery();

                    ClearData();
                   
                    conn.Close();

                    btnupdate.Visible = false;
                    btnsave.Visible = true;
               
                    FillGrid();
                }
                else
                {
                    btnupdate.Visible = true;
                    btnsave.Visible = false;
               
                }
            }
            catch (Exception ex) { }

        }

        protected void lnkview_Click(object sender, EventArgs e) 
        {
            if (conn.State == ConnectionState.Closed)
            {
                conn.Open();
            }
            cmd = new SqlCommand("viewSolutionMaster", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@solution_code", txtsolutioncode.Text);
                   
            ad = new SqlDataAdapter(cmd);
            dataTable = new DataTable();
           
            ad.Fill(dataTable);

            conn.Close();
          //  txtsolutioncode.Text = dataTable.Rows[0]["solution_code"].ToString();
            txtdescription.Text = dataTable.Rows[0]["Description"].ToString();

          /*  if (GridView1.SelectedRow.Cells[2].Text.Equals("True"))
            {
                rblactive.Items[0].Selected = true;
                rblactive.Items[1].Selected = false;

            }
            else
            {
                rblactive.Items[1].Selected = true;
                rblactive.Items[0].Selected = false;

            }
            txtcreatedby.Text = GridView1.SelectedRow.Cells[3].Text;
            txtcreateddate.Text = GridView1.SelectedRow.Cells[4].Text;
          
            */

            

        }

       /* protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtsolutioncode.Text = GridView1.SelectedRow.Cells[0].Text;
            txtdescription.Text = GridView1.SelectedRow.Cells[1].Text;
            rblactive.SelectedValue = GridView1.SelectedRow.Cells[2].Text;
            txtcreatedby.Text = GridView1.SelectedRow.Cells[3].Text;
            txtcreateddate.Text = GridView1.SelectedRow.Cells[4].Text;
            txtupdatedby.Text = GridView1.SelectedRow.Cells[5].Text;
            txtupdateddate.Text = GridView1.SelectedRow.Cells[6].Text;

            btnupdate.Visible = true;
            btnsave.Visible = false;
           
        }*/

    }
}