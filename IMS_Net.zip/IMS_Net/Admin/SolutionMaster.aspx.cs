﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;


namespace IMS_Net.Admin
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString);

        SqlDataAdapter ad = new SqlDataAdapter();

        SqlCommand cmd = new SqlCommand();

        DataTable dataTable;
      
        protected void Page_Load(object sender, EventArgs e)
        {
            lblinsert.Text = "";
            lblupdate.Text = "";

            if (!IsPostBack)
            {
                btnupdate.Visible = false;

                FillGrid();

             //  ClearData();
            }
  
        }

        private void FillGrid()
        {
            try
            {

                dataTable = new DataTable();

                SqlCommand cmd = new SqlCommand("selectSolutionMaster", conn);
                cmd.CommandType = CommandType.StoredProcedure;

                conn.Open();

                cmd.Connection = conn;


                ad = new SqlDataAdapter(cmd);

                ad.Fill(dataTable);

                GridView1.DataSource = dataTable;

                GridView1.DataBind();
            }
            catch (Exception ex) 
            { 
                Response.Write(ex.ToString()); 
            }
            finally
            {
                conn.Close();
            }
        }

        protected void btnclear_Click(object sender, EventArgs e)
        {
            ClearData();
            btnupdate.Visible = false;

            btnsave.Visible = true;

        }

        public void ClearData() 

        {
         
            txtdescription.Text = "";
            
            rblactive.ClearSelection();

            lblinsert.Text = "";
            lblupdate.Text = "";
           

         }
        protected void btnsave_Click(object sender, EventArgs e)
       {
           String name = "jil";
           Session[name] = name;
            try
            {
                if (Page.IsValid)
                {

                    SqlCommand cmd = new SqlCommand("insertSolutionMaster", conn);

                    cmd.CommandType = CommandType.StoredProcedure;


                    cmd.Parameters.AddWithValue("@Description", txtdescription.Text);
                    cmd.Parameters.AddWithValue("@Active", rblactive.SelectedValue);
                    cmd.Parameters.AddWithValue("@CreatedBy", name);
                    cmd.Parameters.AddWithValue("@CreatedDate", DateTime.Now);

                    conn.Open();

                    cmd.Connection = conn;

                    cmd.ExecuteNonQuery();
                }
                
            }

            catch (Exception ex)
            {
                Response.Write(ex.ToString());
            }

            finally 
            {
                conn.Close();

                ClearData();

                FillGrid();

                lblinsert.Visible = true;
                lblinsert.Text = "Saved Successfully.............";
                ClientScript.RegisterStartupScript(this.GetType(), "alert", "HideinsertLabel();", true);

               // lblupdate.Visible = false;
                   
            }

        }

        protected void btnupdate_Click(object sender, EventArgs e)
        {
            
            String updname = "jil";
           
            try
            {
                if (Page.IsValid)
                {
                    SqlCommand cmd = new SqlCommand("updateSolutionMaster", conn);
                    cmd.CommandType = CommandType.StoredProcedure;
                   
                    cmd.Parameters.AddWithValue("@solution_code", txtsolutioncode.Text);
                    cmd.Parameters.AddWithValue("@Description", txtdescription.Text);
                    cmd.Parameters.AddWithValue("@Active", rblactive.SelectedValue);
                    cmd.Parameters.AddWithValue("@CreatedBy", txtcreatedby.Text);
                    cmd.Parameters.AddWithValue("@CreatedDate", txtcreateddate.Text);
                    cmd.Parameters.AddWithValue("@UpdatedBy",updname);
                    cmd.Parameters.AddWithValue("@UpdatedDate", DateTime.Now);

                    if (conn.State == ConnectionState.Closed)
                    {
                        conn.Open();
                    }

                    cmd.ExecuteNonQuery();

                    btnupdate.Visible = false;

                    btnsave.Visible = true;

                  
                }
                else
                {
                    btnupdate.Visible = true;

                    btnsave.Visible = false;

                }
            }

            catch (Exception ex)
            {
                Response.Write(ex.ToString());
            }

            finally
            {
                conn.Close();
                
                ClearData();

               
                FillGrid();

                lblupdate.Visible = true;
                lblupdate.Text = "Updated Successfully............";
                ClientScript.RegisterStartupScript(this.GetType(), "alert", "HideupdateLabel();", true);

               // lblinsert.Visible = false;
            }

        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {
           
            txtsolutioncode.Text = GridView1.SelectedRow.Cells[0].Text;
            txtdescription.Text = GridView1.SelectedRow.Cells[1].Text;
             
            if (GridView1.SelectedRow.Cells[2].Text.Equals("True"))
            {
                rblactive.Items[0].Selected = true;
                rblactive.Items[1].Selected = false;
 
            }
            else
            {
                rblactive.Items[1].Selected = true;
                rblactive.Items[0].Selected = false;
 
            }
            txtcreatedby.Text = GridView1.SelectedRow.Cells[3].Text;
            txtcreateddate.Text = GridView1.SelectedRow.Cells[4].Text;

            lblinsert.Text = "";
            lblupdate.Text = "";
           

            btnupdate.Visible = true;

            btnsave.Visible = false;
           
        }

       
    }
       
}
